#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "spravka.h"
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QString>
#include <QDebug>
#include <QDialog>
#include <QColorDialog>
#include <QFontDialog>
#include <QPlainTextEdit>
#include <QMessageBox>
#include <QWizardPage>
#include <QWidget>
#include <QPushButton>
#include <QTextDocument>
#include <QTextBlock>
#include <QPainter>
#include <QToolButton>
#include <QStyle>
#include <QPixmap>
#include <QDirIterator>
#include <QDateTime>
std::string abbd = "*";
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->plainTextEdit, SIGNAL(cursorPositionChanged()), this, SLOT(on_showCursorPos_triggered()));
    QToolButton* Button = new QToolButton();
    Button->text() = "Найти и Заменить";
    Button->statusTip() = "Найти и Заменить";
    Button->setIcon(QIcon(":/rec/Search.png"));
    QMenu* settingsMenu = new QMenu();
    QAction* first = settingsMenu->addAction(trUtf8("Найти"));
    QAction* second = settingsMenu->addAction(trUtf8("Заменить"));
 connect(first, SIGNAL(triggered()),this, SLOT(on_action_11_triggered()));
 connect(second, SIGNAL(triggered()),this, SLOT(on_action_12_triggered()));
    Button->setMenu(settingsMenu);
    Button->setPopupMode(QToolButton::MenuButtonPopup);
    ui->toolBar->addWidget(Button);

    highlighter = new Highlighter(ui->plainTextEdit->document());
    highlighter->SwitchStandart("C89");
    next = "C89";

    //добавление существующих стилей
    //-----------------------------------------------------------------------------------
    QDir dir("/home/mill3rick/Документы/correct_code_lab_12/");
    QString fileName_DATA;
        QFileInfoList dirfile;
        QFileInfo fileInfo;
         dirfile = dir.entryInfoList(QDir::Files);
         int omg = 0;
         int wtf = 0;
         int kek = 0;
         for (const auto& i : dirfile){
//                   QFile newfile (i.fileName());
                   omg = 0;
                   wtf = 0;
                   kek = 0;
                   QFile file(i.absoluteFilePath());
                   qDebug() << i.absoluteFilePath();
                   if (file.open(QIODevice::ReadOnly)) {
                   fileInfo = file;
                   QString text = file.readLine();
                   if(text.contains("|"))
                   {
                   QStringList list = text.split("|");
                   QColor test;
                   test.setNamedColor(list[0]);
                   if (test.isValid()){
                       mda[0].QColor::setNamedColor(list[0]);
                       omg = 1;
                   }

                   test.setNamedColor(list[1]);
                   if (test.isValid()){
                       mda[1].QColor::setNamedColor(list[1]);
                       wtf = 1;
                   }

                   test.setNamedColor(list[2]);
                   if (test.isValid()){
                       mda[2].QColor::setNamedColor(list[2]);
                       kek = 1;
                   }
                   if (omg == 1 && wtf == 1 && kek == 1){
                   ne_beite.push_back(mda);
                   kostyl++;
                   QAction* a =  ui->menu_7->addAction(fileInfo.fileName().split(".")[0]);
                   MyMap.insert(a, kostyl);
                          connect(a, SIGNAL(triggered()), this, SLOT(on_actionsetstylefrombutton_triggered()));
                       }
                   }
                 }
         }

        on_actionDefault_2_triggered();
    //-----------------------------------------------------------------------------------

}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_action_2_triggered()
{

    //открыть (меню)
    QFileInfo fileInfo;
    QString fileName_DATA;

    fileName_DATA = QFileDialog::getOpenFileName(this, tr("Open File"),"/home/mill3rick/Документы/correct_code_lab_12/",tr("All (*)"));
    QFile file(fileName_DATA);
        if (!file.open(QIODevice::ReadOnly)) {

            return;
        }
        QTextStream in(&file);
        QString text = in.readAll();
        buffer = text;
        ui->plainTextEdit->setPlainText(text);
        file.close();
        OpenedDir = fileName_DATA;
        fileInfo = file.fileName();
        QFileInfo curr(file);
        last_read = curr.lastRead();
        last_mod = curr.lastModified();
        if(fileInfo.fileName().count()<32)
        this->setWindowTitle(fileInfo.fileName());
        else
        {
        this->setWindowTitle((fileInfo.fileName()).mid(0,32)+"...");

        }

}

void MainWindow::on_action_4_triggered()
{
    // сохранить как (меню)
    QString fileName_DATA;
    fileName_DATA = QFileDialog::getSaveFileName(this, tr("Save File"),"/home/mill3rick/Документы/correct_code_lab_12/",tr("All (*)"));
    QFile file(fileName_DATA);
        if (!file.open(QIODevice::WriteOnly)) {

            return;
        }
         QTextStream out(&file);
         out << ui->plainTextEdit->toPlainText();
         buffer = ui->plainTextEdit->toPlainText();
         file.flush();
         file.close();

}

void MainWindow::on_action_3_triggered()
{
    // сохранить (меню)
    QString fileName_DATA;
    if(OpenedDir=="")
    {

        fileName_DATA = QFileDialog::getSaveFileName(this, tr("Save File"),"/home/mill3rick/Документы/correct_code_lab_12/",tr("All (*)"));

    }
    else
    {
       fileName_DATA =  OpenedDir;

    }
    QFile file(fileName_DATA);
        if (!file.open(QIODevice::WriteOnly)) {

            return;
        }
         QTextStream out(&file);
         out << ui->plainTextEdit->toPlainText();
         buffer = ui->plainTextEdit->toPlainText();
         file.flush();
         file.close();
}

void MainWindow::on_action_27_triggered()
{
    //открыть (тулбар)
    QFileInfo fileInfo;
    QString fileName_DATA;

    fileName_DATA = QFileDialog::getOpenFileName(this, tr("Open File"),"/home/mill3rick/Документы/correct_code_lab_12/",tr("All (*)"));
    QFile file(fileName_DATA);
        if (!file.open(QIODevice::ReadOnly)) {

            return;
        }
        QTextStream in(&file);
        QString text = in.readAll();
        buffer = text;
        ui->plainTextEdit->setPlainText(text);
        file.close();
        OpenedDir = fileName_DATA;
        fileInfo = file.fileName();
        if(fileInfo.fileName().count()<32)
        this->setWindowTitle(fileInfo.fileName());
        else
        {
        this->setWindowTitle((fileInfo.fileName()).mid(0,32)+"...");

        }
}

void MainWindow::on_action_28_triggered()
{
    //сохранить (тулбар)
    QString fileName_DATA;
    if(OpenedDir=="")
    {

        fileName_DATA = QFileDialog::getSaveFileName(this, tr("Save File"),"/home/mill3rick/Документы/correct_code_lab_12/",tr("All (*)"));

    }
    else
    {
       fileName_DATA =  OpenedDir;

    }
    QFile file(fileName_DATA);
        if (!file.open(QIODevice::WriteOnly)) {

            return;
        }
         QTextStream out(&file);
         out << ui->plainTextEdit->toPlainText();
         buffer = ui->plainTextEdit->toPlainText();
         file.flush();
         file.close();
}

void MainWindow::on_action_triggered()
{
    //Новый (меню)
    if(buffer!=ui->plainTextEdit->toPlainText())
    {
        QMessageBox* pmbx =
         new QMessageBox(QMessageBox::Information,
         "ALLO",
         "Исходный файл не сохранен. Сохранить?",
         QMessageBox::Yes | QMessageBox::No |
        QMessageBox::Cancel
         );
        int n = pmbx->exec();
        delete pmbx;
        if (n == QMessageBox::Yes) {
         on_action_28_triggered();
         buffer="";
         ui->plainTextEdit->setPlainText("");
        }
        else if(n == QMessageBox::Cancel)
        {}
        else
        {
            buffer="";
            ui->plainTextEdit->setPlainText("");

        }
    }
    else
    {buffer="";
        ui->plainTextEdit->setPlainText("");}
    this->setWindowTitle("New File");
}



void MainWindow::on_action_16_triggered()
{
    //Выбор фона (меню)
    QColor color = QColorDialog::getColor();
    if (!color.isValid()) {

    }
    else
    {
        ui->plainTextEdit->setStyleSheet("QPlainTextEdit {background-color: "+color.name()+";}");
    }
}

void MainWindow::on_action_15_triggered()
{
    //выбор шрифта (меню)
    bool bOk;
    QFont fnt = QFontDialog::getFont(&bOk);

    if (!bOk) {
    }
    else
    {
        ui->plainTextEdit->setFont(fnt);
    }

}

void MainWindow::on_action_14_triggered(bool checked)
{
    //Перенос по словам (меню)
    if(!checked)
    {
        ui->plainTextEdit->setLineWrapMode(ui->plainTextEdit->NoWrap);
    }
    else
    {
        ui->plainTextEdit->setLineWrapMode(ui->plainTextEdit->WidgetWidth);
    }
}

void MainWindow::on_action_26_triggered()
{
    //Новый (тулбар)
    on_action_triggered();
}

void MainWindow::on_action_5_triggered()
{
    //Выход (тулбар)
    if(buffer!=ui->plainTextEdit->toPlainText())
    {
        QMessageBox* pmbx =
         new QMessageBox(QMessageBox::Information,
         "ALLO",
         "Исходный файл не сохранен. Сохранить?",
         QMessageBox::Yes | QMessageBox::No |
        QMessageBox::Cancel
         );
        int n = pmbx->exec();
        delete pmbx;
        if (n == QMessageBox::Yes) {
         on_action_28_triggered();
        close();
        }
        else if(n == QMessageBox::Cancel)
        {}
        else
        {
            close();

        }
    }
    else
    close();
}


void MainWindow::on_Find_text_triggered()
{
    //найти(тулбар)
    QString a = pervii->toPlainText();
    QString b = ui->plainTextEdit->toPlainText();

    if (!ui->plainTextEdit->find(a)){
        ui->plainTextEdit->moveCursor(QTextCursor::Start);
        ui->plainTextEdit->find(a);
        }
}

void MainWindow::on_action_11_triggered()
{
    //Найти (меню)

    pervii = new QTextEdit();
    QPushButton *button1 = new QPushButton("Найти");
    QObject::connect(button1, SIGNAL (released()), this, SLOT (on_Find_text_triggered()));
    QWidget* ppage = new QWidget;
    QVBoxLayout* playout = new QVBoxLayout;
    ppage->setWindowTitle("Найти");
    playout->addWidget(pervii);
    playout->addWidget(button1);
    ppage->setLayout(playout);
    ppage->show();
}





void MainWindow::on_action_19_triggered(bool checked)
{
    //Панель инструментов(меню)
    if(checked)
    ui->toolBar->show();
        else
        ui->toolBar->close();
}

void MainWindow::on_action_20_triggered(bool checked)
{
    //Состояние строки(меню)
    if(checked)
    ui->statusbar->show();
        else
        ui->statusbar->close();
}


void MainWindow::on_action_17_triggered()
{
    //Выбор цвета текущей строки(меню)
    QColor color = QColorDialog::getColor();
        if (!color.isValid()) {

        }
        else
        {
        ui->plainTextEdit->SetColor(color.name());
        }
}

void MainWindow::on_action_12_triggered()
{
    //найти и заменить(меню)
    pervii = new QTextEdit();
    vtoroi = new QTextEdit();
    QPushButton *button1 = new QPushButton("Заменить");
    connect(button1, SIGNAL (released()), this, SLOT (on_Replace_text_triggered()));
    ui->plainTextEdit->moveCursor(QTextCursor::Start);
    QWidget* ppage = new QWidget;
    QVBoxLayout* playout = new QVBoxLayout;
    ppage->setWindowTitle("Заменить");
    playout->addWidget(pervii);
    playout->addWidget(vtoroi);
    playout->addWidget(button1);
    ppage->setLayout(playout);
    ppage->show();

}

void MainWindow::on_Replace_text_triggered()
{

    QString a = pervii->toPlainText();
      ui->plainTextEdit->moveCursor(QTextCursor::Start);
    while (ui->plainTextEdit->find(a)){

    QString b = ui->plainTextEdit->toPlainText();

    QTextCursor cursor = ui->plainTextEdit->textCursor();
    if(cursor.hasSelection())
    {
        cursor.insertText(vtoroi->toPlainText());
    }
    }
}

void MainWindow::on_GoToFind_triggered()
{
   on_action_12_triggered();
}


void MainWindow::on_action_25_triggered()
{
    //C89
    delete highlighter;
    highlighter = nullptr;
    highlighter = new Highlighter(ui->plainTextEdit->document());
    highlighter->SwitchStandart("C89");
    next = "C89";
    highlighter->SetPresetButton(mda,next);
}

void MainWindow::on_action_98_triggered()
{
    delete highlighter;
    highlighter = nullptr;
   highlighter = new Highlighter(ui->plainTextEdit->document());
 highlighter->SwitchStandart("C++98");
 next = "C++98";
 highlighter->SetPresetButton(mda,next);
}

void MainWindow::on_action_03_triggered()
{
    delete highlighter;
    highlighter = nullptr;
    highlighter = new Highlighter(ui->plainTextEdit->document());
    highlighter->SwitchStandart("C++03");
    next = "C++03";
    highlighter->SetPresetButton(mda,next);
}

void MainWindow::on_action_34_triggered()
{
    delete highlighter;
    highlighter = nullptr;
    highlighter = new Highlighter(ui->plainTextEdit->document());
    highlighter->SwitchStandart("C++11");
    next = "C++11";
    highlighter->SetPresetButton(mda,next);
}

void MainWindow::on_action_35_triggered()
{
    delete highlighter;
    highlighter = nullptr;
    highlighter = new Highlighter(ui->plainTextEdit->document());
    highlighter->SwitchStandart("C++14");
    next = "C++14";
    highlighter->SetPresetButton(mda,next);
}

void MainWindow::on_action_36_triggered()
{
    highlighter = new Highlighter(ui->plainTextEdit->document());
    highlighter->SwitchStandart("C++17");
    next = "C++17";
    highlighter->SetPresetButton(mda,next);
}

void MainWindow::on_action_37_triggered()
{
    delete highlighter;
    highlighter = nullptr;
    highlighter = new Highlighter(ui->plainTextEdit->document());
    highlighter->SwitchStandart("C++20");
    next = "C++20";
    highlighter->SetPresetButton(mda,next);
}





void MainWindow::on_action_40_triggered(bool checked)
{
    if (checked){
        delete highlighter;
        highlighter = nullptr;
        highlighter = new Highlighter(ui->plainTextEdit->document());
        highlighter->SwitchStandart("C89");
        next = "C89";
        highlighter->SetPresetButton(mda,next);
        gg = true;
    }
    else{
        delete highlighter;
        highlighter = nullptr;
        highlighter = new Highlighter(ui->plainTextEdit->document());
        next = " ";
        gg = false;
    }
}

void MainWindow::on_action_41_triggered()
{
    //изменить (меню)
        QPushButton *button1 = new QPushButton("Заменить коментарии");
        QWidget* ppage = new QWidget;

        QPushButton *button2 = new QPushButton("Заменить ключевые слова");
        QPushButton *button3 = new QPushButton("Заменить символьные литералы");
        QPushButton *button4 = new QPushButton("Сохранить текущий стиль");
        QVBoxLayout* playout = new QVBoxLayout;
        ppage->setWindowTitle("Изменить Стиль");
        playout->addWidget(button1);
        playout->addWidget(button2);
        playout->addWidget(button3);
        playout->addWidget(button4);
        ppage->setLayout(playout);
        ppage->show();
         connect(button1, SIGNAL (released()), this, SLOT (on_actionfisting_triggered()));
         connect(button2, SIGNAL (released()), this, SLOT (on_actionisthree_triggered()));
         connect(button3, SIGNAL (released()), this, SLOT (on_actionhundredbucks_triggered()));
         connect(button4, SIGNAL (released()), this, SLOT (on_actionsolyanovo_triggered()));
}

void MainWindow::on_actionfisting_triggered()
{
    mda[0] = QColorDialog::getColor();
    if (!mda.at(0).isValid()) {

    }
    else
    {
        delete highlighter;
        highlighter=nullptr;
        highlighter = new Highlighter(ui->plainTextEdit->document());
        if (gg)
            highlighter->SetPresetButton(mda,next);
    }
}

void MainWindow::on_action_22_triggered()
{
    //О программе (меню)
    Spravka nw;
    nw.setModal(true);
    nw.exec();
}

void MainWindow::on_action_6_triggered()
{
//отменить (меню)
    ui->plainTextEdit->undo();
}

void MainWindow::on_action_29_triggered()
{
   //отменить (тулбар)
    ui->plainTextEdit->undo();
}

void MainWindow::on_action_30_triggered()
{
    //повторить (тулбар)
    ui->plainTextEdit->redo();
}

void MainWindow::on_action_7_triggered()
{
    //повторить (меню)
    ui->plainTextEdit->redo();
}

void MainWindow::on_action_31_triggered()
{
    //копировать (тулбар)
    ui->plainTextEdit->copy();
}

void MainWindow::on_action_8_triggered()
{
    //копировать (меню)
    ui->plainTextEdit->copy();
}

void MainWindow::on_action_9_triggered()
{
    //вырезать (меню)
    ui->plainTextEdit->cut();
}

void MainWindow::on_action_32_triggered()
{
    //вырезать (тулбар)
    ui->plainTextEdit->cut();
}

void MainWindow::on_action_10_triggered()
{
    //вставить (меню)
     ui->plainTextEdit->paste();
}

void MainWindow::on_action_33_triggered()
{
    //вставить (тулбар)
     ui->plainTextEdit->paste();
}

void MainWindow::on_action_13_triggered()
{
    //выделить все (меню)
     ui->plainTextEdit->selectAll();
}

void MainWindow::on_actionisthree_triggered()
{
    mda[1] = QColorDialog::getColor();
    if (!mda.at(1).isValid()) {

    }
    else
    {
        delete highlighter;
        highlighter=nullptr;
        highlighter = new Highlighter(ui->plainTextEdit->document());
        if (gg)
            highlighter->SetPresetButton(mda,next);
    }
}

void MainWindow::on_actionhundredbucks_triggered()
{
    mda[2] = QColorDialog::getColor();
    if (!mda.at(2).isValid()) {

    }
    else
    {
        delete highlighter;
        highlighter=nullptr;
        highlighter = new Highlighter(ui->plainTextEdit->document());
        if (gg)
            highlighter->SetPresetButton(mda,next);
    }
}



void MainWindow::on_actionsolyanovo_triggered()
{
    //сохранить
    QString fileName_DATA;
    fileName_DATA = QFileDialog::getSaveFileName(this, tr("Save File"),"/home/mill3rick/Документы/correct_code_lab_12/",tr("All (.font)"));
    QFile file(fileName_DATA);
        if (!file.open(QIODevice::WriteOnly)) {

            return;
        }
         QTextStream out(&file);
         out << ((mda.at(0)!=nullptr)?mda.at(0).name():nullptr) +"|"+((mda.at(1)!=nullptr)?mda.at(1).name():nullptr)+"|"+((mda.at(2)!=nullptr)?mda.at(2).name():nullptr);
         file.flush();
         file.close();
}

void MainWindow::on_action_42_triggered()
{
    QFileInfo fileInfo;
        QString fileName_DATA;

        fileName_DATA = QFileDialog::getOpenFileName(this, tr("Open File"),"/home/mill3rick/Документы/correct_code_lab_12/",tr("All (*)"));
        QFile file(fileName_DATA);
            if (!file.open(QIODevice::ReadOnly)) {

                return;
            }
        fileInfo = file;
            QTextStream in(&file);
            QString text = in.readLine();
            QStringList list = text.split("|");

            delete highlighter;
            highlighter=nullptr;
            highlighter = new Highlighter(ui->plainTextEdit->document());
            QColor test;
            test.setNamedColor(list[0]);
            int omg = 0;
            int wtf = 0;
            int kek = 0;

            if (test.isValid()){
                mda[0].QColor::setNamedColor(list[0]);
                omg = 1;
            }

            test.setNamedColor(list[1]);
            if (test.isValid()){
                mda[1].QColor::setNamedColor(list[1]);
                wtf = 1;
            }
            test.setNamedColor(list[2]);
            if (test.isValid()){
                mda[2].QColor::setNamedColor(list[2]);
            kek = 1;
            }
            if (omg == 1 && wtf ==1 && kek == 1){
            kostyl++;
            ne_beite.push_back(mda);
            if(gg)
            highlighter->SetPresetButton(mda,next);

           QAction* a =  ui->menu_7->addAction(fileInfo.fileName().split(".")[0]);
            //fileInfo.fileName().split(".")[0]
           MyMap.insert(a, kostyl);
           connect(a, SIGNAL(triggered()), this, SLOT(on_actionsetstylefrombutton_triggered));

            }
            else
                highlighter->SetPresetButton(mda,next);

}

void MainWindow::on_action_18_triggered(bool checked)
{
    if(checked)
        ui->plainTextEdit->lineNumberArea->show();
        else
        ui->plainTextEdit->lineNumberArea->hide();
}

void MainWindow::on_actionDefault_2_triggered()
{
    delete highlighter;
    highlighter = nullptr;
    highlighter = new Highlighter(ui->plainTextEdit->document());
    mda[0].setNamedColor("#b40000");
    mda[1].setNamedColor("#14148c");
    mda[2].setNamedColor("#006325");
    highlighter->SetPresetButton(mda,next);
}

void MainWindow::on_actionsetstylefrombutton_triggered()
{
    QAction* action = qobject_cast<QAction*>(sender());
        if(gg)
        {
        delete highlighter;
        highlighter=nullptr;
        highlighter = new Highlighter(ui->plainTextEdit->document());
        mda = ne_beite.at(MyMap.value(action));
        highlighter->SetPresetButton(mda,next);
        }
        else
        {
         mda = ne_beite.at(MyMap.value(action));
        }
}

void MainWindow::on_showCursorPos_triggered()
{
    if(buffer!=ui->plainTextEdit->toPlainText()&&(((this->windowTitle()).toStdString().at(0)))!=abbd.at(0))

        {
            bufname = this->windowTitle();
            this->setWindowTitle("*"+bufname);
        }
        else if(buffer==ui->plainTextEdit->toPlainText())
        {
            this->setWindowTitle(bufname);
        }



    ui->statusbar->showMessage(QString("Ln %1, Col %2,Size in KB: %3,Lines: %4,Symbols: %5,Words: %6,Last modified: %7,Last read: %8")
                               .arg(ui->plainTextEdit->textCursor().blockNumber()+1)
                               .arg(ui->plainTextEdit->textCursor().columnNumber()+1)
                               .arg(float(ui->plainTextEdit->document()->size().toSize().width())/8000)
                               .arg(ui->plainTextEdit->document()->size().toSize().height())
                               .arg(ui->plainTextEdit->toPlainText().length())
                               .arg(ui->plainTextEdit->toPlainText().split(QRegExp("(\\s|\\n|\\r)+"), QString::SkipEmptyParts).count())
                               .arg(last_mod.toString())
                               .arg(last_read.toString()));
}
