#ifndef SPRAVKA_H
#define SPRAVKA_H
#pragma once
#include <QDialog>

namespace Ui {
class Spravka;
}

class Spravka : public QDialog
{
    Q_OBJECT

public:
    explicit Spravka(QWidget *parent = nullptr);
    ~Spravka();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Spravka *ui;
};

#endif // SPRAVKA_H
