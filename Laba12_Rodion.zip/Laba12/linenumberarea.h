#ifndef LINENUMBERAREA_H
#define LINENUMBERAREA_H
#pragma once
#include <QWidget>
#include <QPlainTextEdit>
#include "qtextedithighlighter.h"
class LineNumberArea : public QWidget
{
    Q_OBJECT

public:
    LineNumberArea(QPlainTextEdit *editor);

    QSize sizeHint() const;

protected:
    void paintEvent(QPaintEvent *event);

private:
    QPlainTextEdit *codeEditor;
};

#endif // LINENUMBERAREA_H
