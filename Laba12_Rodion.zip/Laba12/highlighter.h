#ifndef HIGHLIGHTER_H
#define HIGHLIGHTER_H
#pragma once
#include <QSyntaxHighlighter>

#include <QHash>
#include <QTextCharFormat>
#include <string>
#include <QString>


class Highlighter : public QSyntaxHighlighter
{
    Q_OBJECT

public:
    QStringList keywordPatternsC89;
    Highlighter(QTextDocument *parent = 0);
    void SwitchStandart(const std::string& stndrt);
    void SetPresetButton(QVector<QColor> a, std::string b);

protected:
    void highlightBlock(const QString &text) override;


private:
    struct HighlightingRule
    {
        QRegExp pattern;
        QTextCharFormat format;
    };
    QVector<HighlightingRule> highlightingRules;

    QRegExp commentStartExpression;
    QRegExp commentEndExpression;

    QTextCharFormat keywordFormat;
    QTextCharFormat classFormat;
    QTextCharFormat singleLineCommentFormat;
    QTextCharFormat multiLineCommentFormat;
    QTextCharFormat quotationFormat;
    QTextCharFormat functionFormat;
    int s = 0;
};


#endif // HIGHLIGHTER_H
