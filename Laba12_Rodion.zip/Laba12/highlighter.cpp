#include "highlighter.h"
#include <vector>
#include <QVector>
#include <iostream>
Highlighter::Highlighter(QTextDocument *parent)
    : QSyntaxHighlighter(parent)
{

    HighlightingRule rule;

       keywordFormat.setForeground(Qt::darkBlue);
       keywordFormat.setFontWeight(QFont::Bold);
       classFormat.setFontWeight(QFont::Bold);
           classFormat.setForeground(Qt::darkMagenta);
           rule.pattern = QRegExp(QString("\\bQ[A-Za-z]+\\b"));
           rule.format = classFormat;
           highlightingRules.append(rule);

           quotationFormat.setForeground(Qt::darkGreen);
           rule.pattern = QRegExp(QString("\".*\""));
           rule.format = quotationFormat;
           highlightingRules.append(rule);

           functionFormat.setFontItalic(true);
           functionFormat.setForeground(Qt::blue);
           rule.pattern = QRegExp(QString("\\b[A-Za-z0-9_]+(?=\\()"));
           rule.format = functionFormat;
           highlightingRules.append(rule);
           singleLineCommentFormat.setForeground(Qt::red);
               rule.pattern = QRegExp(QString("//[^\n]*"));
               rule.format = singleLineCommentFormat;
               highlightingRules.append(rule);

               multiLineCommentFormat.setForeground(Qt::red);

               commentStartExpression = QRegExp(QString("/\\*"));
               multiLineCommentFormat.setForeground(Qt::red);
               commentEndExpression = QRegExp(QString("\\*/"));
}

void Highlighter::highlightBlock(const QString &text)
{
    foreach (const HighlightingRule &rule, highlightingRules) {
            QRegExp expression(rule.pattern);
            int index = expression.indexIn(text);
            while (index >= 0) {
                int length = expression.matchedLength();
                setFormat(index, length, rule.format);
                index = expression.indexIn(text, index + length);
            }
        }
        setCurrentBlockState(0);

        int startIndex = 0;
        if (previousBlockState() != 1)
            startIndex = commentStartExpression.indexIn(text);

        while (startIndex >= 0) {
            int endIndex = commentEndExpression.indexIn(text, startIndex);
            int commentLength;
            if (endIndex == -1) {
                setCurrentBlockState(1);
                commentLength = text.length() - startIndex;
            } else {
                commentLength = endIndex - startIndex
                                + commentEndExpression.matchedLength();
            }
            setFormat(startIndex, commentLength, multiLineCommentFormat);
            startIndex = commentStartExpression.indexIn(text, startIndex + commentLength);
        }
           }

void Highlighter::SwitchStandart(const std::string& stndrt){
    if (stndrt == "C89")
        s = 1;
    else if (stndrt == "C++98")
        s = 2;
    else if (stndrt == "C++03")
        s = 3;
    else if (stndrt == "C++11")
        s = 4;
    else if (stndrt == "C++14")
        s = 5;
    else if (stndrt == "C++17")
        s = 6;
    else if (stndrt == "C++20")
        s = 7;
    HighlightingRule rule;

    keywordFormat.setForeground(Qt::darkBlue);
    keywordFormat.setFontWeight(QFont::Bold);

    switch (s){

    case 1:

    keywordPatternsC89 << "\\bauto\\b";
    keywordPatternsC89 << "\\bbreak\\b";
    keywordPatternsC89 << "\\bcase\\b";
    keywordPatternsC89 << "\\bchar\\b";
    keywordPatternsC89 << "\\bconst\\b";
    keywordPatternsC89 << "\\bcontinue\\b";
    keywordPatternsC89 << "\\bdefault\\b";
    keywordPatternsC89 << "\\bdo\\b";
    keywordPatternsC89 << "\\bdouble\\b";
    keywordPatternsC89 << "\\belse\\b";
    keywordPatternsC89 << "\\benum\\b";
    keywordPatternsC89 << "\\bextern\\b";
    keywordPatternsC89 << "\\bfloat\\b";
    keywordPatternsC89 << "\\bfor\\b";
    keywordPatternsC89 << "\\bgoto\\b";
    keywordPatternsC89 << "\\bif\\b";
    keywordPatternsC89 << "\\bint\\b";
    keywordPatternsC89 << "\\blong\\b";
    keywordPatternsC89 << "\\bregister\\b";
    keywordPatternsC89 << "\\breturn\\b";
    keywordPatternsC89 << "\\bshort\\b";
    keywordPatternsC89 << "\\bsigned\\b";
    keywordPatternsC89 << "\\bsizeof\\b";
    keywordPatternsC89 << "\\bstatic\\b";
    keywordPatternsC89 << "\\bstruct\\b";
    keywordPatternsC89 << "\\bswitch\\b";
    keywordPatternsC89 << "\\btypedef\\b";
    keywordPatternsC89 << "\\bunion\\b";
    keywordPatternsC89 << "\\bunsigned\\b";
    keywordPatternsC89 << "\\bvoid\\b";
    keywordPatternsC89 << "\\bvolatile\\b";
    keywordPatternsC89 << "\\bwhile\\b";



        break;

        case 2:
        keywordPatternsC89 << "\\bauto\\b";
        keywordPatternsC89 << "\\bbreak\\b";
        keywordPatternsC89 << "\\bcase\\b";
        keywordPatternsC89 << "\\bchar\\b";
        keywordPatternsC89 << "\\bconst\\b";
        keywordPatternsC89 << "\\bcontinue\\b";
        keywordPatternsC89 << "\\bdefault\\b";
        keywordPatternsC89 << "\\bdo\\b";
        keywordPatternsC89 << "\\bdouble\\b";
        keywordPatternsC89 << "\\belse\\b";
        keywordPatternsC89 << "\\benum\\b";
        keywordPatternsC89 << "\\bextern\\b";
        keywordPatternsC89 << "\\bfloat\\b";
        keywordPatternsC89 << "\\bfor\\b";
        keywordPatternsC89 << "\\bgoto\\b";
        keywordPatternsC89 << "\\bif\\b";
        keywordPatternsC89 << "\\bint\\b";
        keywordPatternsC89 << "\\blong\\b";
        keywordPatternsC89 << "\\bregister\\b";
        keywordPatternsC89 << "\\breturn\\b";
        keywordPatternsC89 << "\\bshort\\b";
        keywordPatternsC89 << "\\bsigned\\b";
        keywordPatternsC89 << "\\bsizeof\\b";
        keywordPatternsC89 << "\\bstatic\\b";
        keywordPatternsC89 << "\\bstruct\\b";
        keywordPatternsC89 << "\\bswitch\\b";
        keywordPatternsC89 << "\\btypedef\\b";
        keywordPatternsC89 << "\\bunion\\b";
        keywordPatternsC89 << "\\bunsigned\\b";
        keywordPatternsC89 << "\\bvoid\\b";
        keywordPatternsC89 << "\\bvolatile\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\band\\b";
        keywordPatternsC89 << "\\band_eq\\b";
        keywordPatternsC89 << "\\basm\\b";
        keywordPatternsC89 << "\\bbitand\\b";
        keywordPatternsC89 << "\\bbitor\\b";
        keywordPatternsC89 << "\\bbool\\b";
        keywordPatternsC89 << "\\bcatch\\b";
        keywordPatternsC89 << "\\bclass\\b";
        keywordPatternsC89 << "\\bcompl\\b";
        keywordPatternsC89 << "\\bconst_cast\\b";
        keywordPatternsC89 << "\\bdelete\\b";
        keywordPatternsC89 << "\\bdynamic_cast\\b";
        keywordPatternsC89 << "\\bexplicit\\b";
        keywordPatternsC89 << "\\bexport\\b";
        keywordPatternsC89 << "\\bfalse\\b";
        keywordPatternsC89 << "\\bfriend\\b";
        keywordPatternsC89 << "\\binline\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\bmutable\\b";
        keywordPatternsC89 << "\\bnamespace\\b";
        keywordPatternsC89 << "\\bnew\\b";
        keywordPatternsC89 << "\\bnot\\b";
        keywordPatternsC89 << "\\bnot_eq\\b";
        keywordPatternsC89 << "\\boperator\\b";
        keywordPatternsC89 << "\\bor\\b";
        keywordPatternsC89 << "\\bor_eq\\b";
        keywordPatternsC89 << "\\bprivate\\b";
        keywordPatternsC89 << "\\bprotected\\b";
        keywordPatternsC89 << "\\bpublic\\b";
        keywordPatternsC89 << "\\breinterpret_cast\\b";
        keywordPatternsC89 << "\\bstatic_cast\\b";
        keywordPatternsC89 << "\\btemplate\\b";
        keywordPatternsC89 << "\\bthis\\b";
        keywordPatternsC89 << "\\bthrow\\b";
        keywordPatternsC89 << "\\btrue\\b";
        keywordPatternsC89 << "\\btry\\b";
        keywordPatternsC89 << "\\btypeid\\b";
        keywordPatternsC89 << "\\btypename\\b";
        keywordPatternsC89 << "\\busing\\b";
        keywordPatternsC89 << "\\bvirtual\\b";
        keywordPatternsC89 << "\\bwchar_t\\b";
        keywordPatternsC89 << "\\bxor\\b";
        keywordPatternsC89 << "\\bxor_eq\\b";





        break;

        case 3:
        keywordPatternsC89 << "\\bauto\\b";
        keywordPatternsC89 << "\\bbreak\\b";
        keywordPatternsC89 << "\\bcase\\b";
        keywordPatternsC89 << "\\bchar\\b";
        keywordPatternsC89 << "\\bconst\\b";
        keywordPatternsC89 << "\\bcontinue\\b";
        keywordPatternsC89 << "\\bdefault\\b";
        keywordPatternsC89 << "\\bdo\\b";
        keywordPatternsC89 << "\\bdouble\\b";
        keywordPatternsC89 << "\\belse\\b";
        keywordPatternsC89 << "\\benum\\b";
        keywordPatternsC89 << "\\bextern\\b";
        keywordPatternsC89 << "\\bfloat\\b";
        keywordPatternsC89 << "\\bfor\\b";
        keywordPatternsC89 << "\\bgoto\\b";
        keywordPatternsC89 << "\\bif\\b";
        keywordPatternsC89 << "\\bint\\b";
        keywordPatternsC89 << "\\blong\\b";
        keywordPatternsC89 << "\\bregister\\b";
        keywordPatternsC89 << "\\breturn\\b";
        keywordPatternsC89 << "\\bshort\\b";
        keywordPatternsC89 << "\\bsigned\\b";
        keywordPatternsC89 << "\\bsizeof\\b";
        keywordPatternsC89 << "\\bstatic\\b";
        keywordPatternsC89 << "\\bstruct\\b";
        keywordPatternsC89 << "\\bswitch\\b";
        keywordPatternsC89 << "\\btypedef\\b";
        keywordPatternsC89 << "\\bunion\\b";
        keywordPatternsC89 << "\\bunsigned\\b";
        keywordPatternsC89 << "\\bvoid\\b";
        keywordPatternsC89 << "\\bvolatile\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\band\\b";
        keywordPatternsC89 << "\\band_eq\\b";
        keywordPatternsC89 << "\\basm\\b";
        keywordPatternsC89 << "\\bbitand\\b";
        keywordPatternsC89 << "\\bbitor\\b";
        keywordPatternsC89 << "\\bbool\\b";
        keywordPatternsC89 << "\\bcatch\\b";
        keywordPatternsC89 << "\\bclass\\b";
        keywordPatternsC89 << "\\bcompl\\b";
        keywordPatternsC89 << "\\bconst_cast\\b";
        keywordPatternsC89 << "\\bdelete\\b";
        keywordPatternsC89 << "\\bdynamic_cast\\b";
        keywordPatternsC89 << "\\bexplicit\\b";
        keywordPatternsC89 << "\\bexport\\b";
        keywordPatternsC89 << "\\bfalse\\b";
        keywordPatternsC89 << "\\bfriend\\b";
        keywordPatternsC89 << "\\binline\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\bmutable\\b";
        keywordPatternsC89 << "\\bnamespace\\b";
        keywordPatternsC89 << "\\bnew\\b";
        keywordPatternsC89 << "\\bnot\\b";
        keywordPatternsC89 << "\\bnot_eq\\b";
        keywordPatternsC89 << "\\boperator\\b";
        keywordPatternsC89 << "\\bor\\b";
        keywordPatternsC89 << "\\bor_eq\\b";
        keywordPatternsC89 << "\\bprivate\\b";
        keywordPatternsC89 << "\\bprotected\\b";
        keywordPatternsC89 << "\\bpublic\\b";
        keywordPatternsC89 << "\\breinterpret_cast\\b";
        keywordPatternsC89 << "\\bstatic_cast\\b";
        keywordPatternsC89 << "\\btemplate\\b";
        keywordPatternsC89 << "\\bthis\\b";
        keywordPatternsC89 << "\\bthrow\\b";
        keywordPatternsC89 << "\\btrue\\b";
        keywordPatternsC89 << "\\btry\\b";
        keywordPatternsC89 << "\\btypeid\\b";
        keywordPatternsC89 << "\\btypename\\b";
        keywordPatternsC89 << "\\busing\\b";
        keywordPatternsC89 << "\\bvirtual\\b";
        keywordPatternsC89 << "\\bwchar_t\\b";
        keywordPatternsC89 << "\\bxor\\b";
        keywordPatternsC89 << "\\bxor_eq\\b";

         keywordPatternsC89 << "\\balignas\\b";
          keywordPatternsC89 << "\\balignof\\b";
           keywordPatternsC89 << "\\bchar16_t\\b";
            keywordPatternsC89 << "\\bchar32_t\\b";
              keywordPatternsC89 << "\\bdecltype\\b";
               keywordPatternsC89 << "\\bnoexcept\\b";
                  keywordPatternsC89 << "\\bthread_local\\b";


        break;
        case 4:
        keywordPatternsC89 << "\\bauto\\b";
        keywordPatternsC89 << "\\bbreak\\b";
        keywordPatternsC89 << "\\bcase\\b";
        keywordPatternsC89 << "\\bchar\\b";
        keywordPatternsC89 << "\\bconst\\b";
        keywordPatternsC89 << "\\bcontinue\\b";
        keywordPatternsC89 << "\\bdefault\\b";
        keywordPatternsC89 << "\\bdo\\b";
        keywordPatternsC89 << "\\bdouble\\b";
        keywordPatternsC89 << "\\belse\\b";
        keywordPatternsC89 << "\\benum\\b";
        keywordPatternsC89 << "\\bextern\\b";
        keywordPatternsC89 << "\\bfloat\\b";
        keywordPatternsC89 << "\\bfor\\b";
        keywordPatternsC89 << "\\bgoto\\b";
        keywordPatternsC89 << "\\bif\\b";
        keywordPatternsC89 << "\\bint\\b";
        keywordPatternsC89 << "\\blong\\b";
        keywordPatternsC89 << "\\bregister\\b";
        keywordPatternsC89 << "\\breturn\\b";
        keywordPatternsC89 << "\\bshort\\b";
        keywordPatternsC89 << "\\bsigned\\b";
        keywordPatternsC89 << "\\bsizeof\\b";
        keywordPatternsC89 << "\\bstatic\\b";
        keywordPatternsC89 << "\\bstruct\\b";
        keywordPatternsC89 << "\\bswitch\\b";
        keywordPatternsC89 << "\\btypedef\\b";
        keywordPatternsC89 << "\\bunion\\b";
        keywordPatternsC89 << "\\bunsigned\\b";
        keywordPatternsC89 << "\\bvoid\\b";
        keywordPatternsC89 << "\\bvolatile\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\band\\b";
        keywordPatternsC89 << "\\band_eq\\b";
        keywordPatternsC89 << "\\basm\\b";
        keywordPatternsC89 << "\\bbitand\\b";
        keywordPatternsC89 << "\\bbitor\\b";
        keywordPatternsC89 << "\\bbool\\b";
        keywordPatternsC89 << "\\bcatch\\b";
        keywordPatternsC89 << "\\bclass\\b";
        keywordPatternsC89 << "\\bcompl\\b";
        keywordPatternsC89 << "\\bconst_cast\\b";
        keywordPatternsC89 << "\\bdelete\\b";
        keywordPatternsC89 << "\\bdynamic_cast\\b";
        keywordPatternsC89 << "\\bexplicit\\b";
        keywordPatternsC89 << "\\bexport\\b";
        keywordPatternsC89 << "\\bfalse\\b";
        keywordPatternsC89 << "\\bfriend\\b";
        keywordPatternsC89 << "\\binline\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\bmutable\\b";
        keywordPatternsC89 << "\\bnamespace\\b";
        keywordPatternsC89 << "\\bnew\\b";
        keywordPatternsC89 << "\\bnot\\b";
        keywordPatternsC89 << "\\bnot_eq\\b";
        keywordPatternsC89 << "\\boperator\\b";
        keywordPatternsC89 << "\\bor\\b";
        keywordPatternsC89 << "\\bor_eq\\b";
        keywordPatternsC89 << "\\bprivate\\b";
        keywordPatternsC89 << "\\bprotected\\b";
        keywordPatternsC89 << "\\bpublic\\b";
        keywordPatternsC89 << "\\breinterpret_cast\\b";
        keywordPatternsC89 << "\\bstatic_cast\\b";
        keywordPatternsC89 << "\\btemplate\\b";
        keywordPatternsC89 << "\\bthis\\b";
        keywordPatternsC89 << "\\bthrow\\b";
        keywordPatternsC89 << "\\btrue\\b";
        keywordPatternsC89 << "\\btry\\b";
        keywordPatternsC89 << "\\btypeid\\b";
        keywordPatternsC89 << "\\btypename\\b";
        keywordPatternsC89 << "\\busing\\b";
        keywordPatternsC89 << "\\bvirtual\\b";
        keywordPatternsC89 << "\\bwchar_t\\b";
        keywordPatternsC89 << "\\bxor\\b";
        keywordPatternsC89 << "\\bxor_eq\\b";

         keywordPatternsC89 << "\\balignas\\b";
          keywordPatternsC89 << "\\balignof\\b";
           keywordPatternsC89 << "\\bchar16_t\\b";
            keywordPatternsC89 << "\\bchar32_t\\b";
             keywordPatternsC89 << "\\bconstexpr\\b";
              keywordPatternsC89 << "\\bdecltype\\b";
               keywordPatternsC89 << "\\bnoexcept\\b";
                keywordPatternsC89 << "\\bnullptr\\b";
                 keywordPatternsC89 << "\\bstatic_assert\\b";
                  keywordPatternsC89 << "\\bthread_local\\b";


        break;
        case 5:
        keywordPatternsC89 << "\\bauto\\b";
        keywordPatternsC89 << "\\bbreak\\b";
        keywordPatternsC89 << "\\bcase\\b";
        keywordPatternsC89 << "\\bchar\\b";
        keywordPatternsC89 << "\\bconst\\b";
        keywordPatternsC89 << "\\bcontinue\\b";
        keywordPatternsC89 << "\\bdefault\\b";
        keywordPatternsC89 << "\\bdo\\b";
        keywordPatternsC89 << "\\bdouble\\b";
        keywordPatternsC89 << "\\belse\\b";
        keywordPatternsC89 << "\\benum\\b";
        keywordPatternsC89 << "\\bextern\\b";
        keywordPatternsC89 << "\\bfloat\\b";
        keywordPatternsC89 << "\\bfor\\b";
        keywordPatternsC89 << "\\bgoto\\b";
        keywordPatternsC89 << "\\bif\\b";
        keywordPatternsC89 << "\\bint\\b";
        keywordPatternsC89 << "\\blong\\b";
        keywordPatternsC89 << "\\breturn\\b";
        keywordPatternsC89 << "\\bshort\\b";
        keywordPatternsC89 << "\\bsigned\\b";
        keywordPatternsC89 << "\\bsizeof\\b";
        keywordPatternsC89 << "\\bstatic\\b";
        keywordPatternsC89 << "\\bstruct\\b";
        keywordPatternsC89 << "\\bswitch\\b";
        keywordPatternsC89 << "\\btypedef\\b";
        keywordPatternsC89 << "\\bunion\\b";
        keywordPatternsC89 << "\\bunsigned\\b";
        keywordPatternsC89 << "\\bvoid\\b";
        keywordPatternsC89 << "\\bvolatile\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\band\\b";
        keywordPatternsC89 << "\\band_eq\\b";
        keywordPatternsC89 << "\\basm\\b";
        keywordPatternsC89 << "\\bbitand\\b";
        keywordPatternsC89 << "\\bbitor\\b";
        keywordPatternsC89 << "\\bbool\\b";
        keywordPatternsC89 << "\\bcatch\\b";
        keywordPatternsC89 << "\\bclass\\b";
        keywordPatternsC89 << "\\bcompl\\b";
        keywordPatternsC89 << "\\bconst_cast\\b";
        keywordPatternsC89 << "\\bdelete\\b";
        keywordPatternsC89 << "\\bdynamic_cast\\b";
        keywordPatternsC89 << "\\bexplicit\\b";
        keywordPatternsC89 << "\\bexport\\b";
        keywordPatternsC89 << "\\bfalse\\b";
        keywordPatternsC89 << "\\bfriend\\b";
        keywordPatternsC89 << "\\binline\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\bmutable\\b";
        keywordPatternsC89 << "\\bnamespace\\b";
        keywordPatternsC89 << "\\bnew\\b";
        keywordPatternsC89 << "\\bnot\\b";
        keywordPatternsC89 << "\\bnot_eq\\b";
        keywordPatternsC89 << "\\boperator\\b";
        keywordPatternsC89 << "\\bor\\b";
        keywordPatternsC89 << "\\bor_eq\\b";
        keywordPatternsC89 << "\\bprivate\\b";
        keywordPatternsC89 << "\\bprotected\\b";
        keywordPatternsC89 << "\\bpublic\\b";
        keywordPatternsC89 << "\\breinterpret_cast\\b";
        keywordPatternsC89 << "\\bstatic_cast\\b";
        keywordPatternsC89 << "\\btemplate\\b";
        keywordPatternsC89 << "\\bthis\\b";
        keywordPatternsC89 << "\\bthrow\\b";
        keywordPatternsC89 << "\\btrue\\b";
        keywordPatternsC89 << "\\btry\\b";
        keywordPatternsC89 << "\\btypeid\\b";
        keywordPatternsC89 << "\\btypename\\b";
        keywordPatternsC89 << "\\busing\\b";
        keywordPatternsC89 << "\\bvirtual\\b";
        keywordPatternsC89 << "\\bwchar_t\\b";
        keywordPatternsC89 << "\\bxor\\b";
        keywordPatternsC89 << "\\bxor_eq\\b";

         keywordPatternsC89 << "\\balignas\\b";
          keywordPatternsC89 << "\\balignof\\b";
           keywordPatternsC89 << "\\bchar16_t\\b";
            keywordPatternsC89 << "\\bchar32_t\\b";
             keywordPatternsC89 << "\\bconstexpr\\b";
              keywordPatternsC89 << "\\bdecltype\\b";
               keywordPatternsC89 << "\\bnoexcept\\b";
                keywordPatternsC89 << "\\bnullptr\\b";
                 keywordPatternsC89 << "\\bstatic_assert\\b";
                  keywordPatternsC89 << "\\bthread_local\\b";

        break;
        case 6:
        keywordPatternsC89 << "\\bauto\\b";
        keywordPatternsC89 << "\\bbreak\\b";
        keywordPatternsC89 << "\\bcase\\b";
        keywordPatternsC89 << "\\bchar\\b";
        keywordPatternsC89 << "\\bconst\\b";
        keywordPatternsC89 << "\\bcontinue\\b";
        keywordPatternsC89 << "\\bdefault\\b";
        keywordPatternsC89 << "\\bdo\\b";
        keywordPatternsC89 << "\\bdouble\\b";
        keywordPatternsC89 << "\\belse\\b";
        keywordPatternsC89 << "\\benum\\b";
        keywordPatternsC89 << "\\bextern\\b";
        keywordPatternsC89 << "\\bfloat\\b";
        keywordPatternsC89 << "\\bfor\\b";
        keywordPatternsC89 << "\\bgoto\\b";
        keywordPatternsC89 << "\\bif\\b";
        keywordPatternsC89 << "\\bint\\b";
        keywordPatternsC89 << "\\blong\\b";
        keywordPatternsC89 << "\\bregister\\b";
        keywordPatternsC89 << "\\breturn\\b";
        keywordPatternsC89 << "\\bshort\\b";
        keywordPatternsC89 << "\\bsigned\\b";
        keywordPatternsC89 << "\\bsizeof\\b";
        keywordPatternsC89 << "\\bstatic\\b";
        keywordPatternsC89 << "\\bstruct\\b";
        keywordPatternsC89 << "\\bswitch\\b";
        keywordPatternsC89 << "\\btypedef\\b";
        keywordPatternsC89 << "\\bunion\\b";
        keywordPatternsC89 << "\\bunsigned\\b";
        keywordPatternsC89 << "\\bvoid\\b";
        keywordPatternsC89 << "\\bvolatile\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\band\\b";
        keywordPatternsC89 << "\\band_eq\\b";
        keywordPatternsC89 << "\\basm\\b";
        keywordPatternsC89 << "\\bbitand\\b";
        keywordPatternsC89 << "\\bbitor\\b";
        keywordPatternsC89 << "\\bbool\\b";
        keywordPatternsC89 << "\\bcatch\\b";
        keywordPatternsC89 << "\\bclass\\b";
        keywordPatternsC89 << "\\bcompl\\b";
        keywordPatternsC89 << "\\bconst_cast\\b";
        keywordPatternsC89 << "\\bdelete\\b";
        keywordPatternsC89 << "\\bdynamic_cast\\b";
        keywordPatternsC89 << "\\bexplicit\\b";
        keywordPatternsC89 << "\\bexport\\b";
        keywordPatternsC89 << "\\bfalse\\b";
        keywordPatternsC89 << "\\bfriend\\b";
        keywordPatternsC89 << "\\binline\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\bmutable\\b";
        keywordPatternsC89 << "\\bnamespace\\b";
        keywordPatternsC89 << "\\bnew\\b";
        keywordPatternsC89 << "\\bnot\\b";
        keywordPatternsC89 << "\\bnot_eq\\b";
        keywordPatternsC89 << "\\boperator\\b";
        keywordPatternsC89 << "\\bor\\b";
        keywordPatternsC89 << "\\bor_eq\\b";
        keywordPatternsC89 << "\\bprivate\\b";
        keywordPatternsC89 << "\\bprotected\\b";
        keywordPatternsC89 << "\\bpublic\\b";
        keywordPatternsC89 << "\\breinterpret_cast\\b";
        keywordPatternsC89 << "\\bstatic_cast\\b";
        keywordPatternsC89 << "\\btemplate\\b";
        keywordPatternsC89 << "\\bthis\\b";
        keywordPatternsC89 << "\\bthrow\\b";
        keywordPatternsC89 << "\\btrue\\b";
        keywordPatternsC89 << "\\btry\\b";
        keywordPatternsC89 << "\\btypeid\\b";
        keywordPatternsC89 << "\\btypename\\b";
        keywordPatternsC89 << "\\busing\\b";
        keywordPatternsC89 << "\\bvirtual\\b";
        keywordPatternsC89 << "\\bwchar_t\\b";
        keywordPatternsC89 << "\\bxor\\b";
        keywordPatternsC89 << "\\bxor_eq\\b";

         keywordPatternsC89 << "\\balignas\\b";
          keywordPatternsC89 << "\\balignof\\b";
           keywordPatternsC89 << "\\bchar16_t\\b";
            keywordPatternsC89 << "\\bchar32_t\\b";
             keywordPatternsC89 << "\\bconstexpr\\b";
              keywordPatternsC89 << "\\bdecltype\\b";
               keywordPatternsC89 << "\\bnoexcept\\b";
                keywordPatternsC89 << "\\bnullptr\\b";
                 keywordPatternsC89 << "\\bstatic_assert\\b";
                  keywordPatternsC89 << "\\bthread_local\\b";
        break;
    case 7:
        keywordPatternsC89 << "\\bauto\\b";
        keywordPatternsC89 << "\\bbreak\\b";
        keywordPatternsC89 << "\\bcase\\b";
        keywordPatternsC89 << "\\bchar\\b";
        keywordPatternsC89 << "\\bconst\\b";
        keywordPatternsC89 << "\\bcontinue\\b";
        keywordPatternsC89 << "\\bdefault\\b";
        keywordPatternsC89 << "\\bdo\\b";
        keywordPatternsC89 << "\\bdouble\\b";
        keywordPatternsC89 << "\\belse\\b";
        keywordPatternsC89 << "\\benum\\b";
        keywordPatternsC89 << "\\bextern\\b";
        keywordPatternsC89 << "\\bfloat\\b";
        keywordPatternsC89 << "\\bfor\\b";
        keywordPatternsC89 << "\\bgoto\\b";
        keywordPatternsC89 << "\\bif\\b";
        keywordPatternsC89 << "\\bint\\b";
        keywordPatternsC89 << "\\blong\\b";
        keywordPatternsC89 << "\\bregister\\b";
        keywordPatternsC89 << "\\breturn\\b";
        keywordPatternsC89 << "\\bshort\\b";
        keywordPatternsC89 << "\\bsigned\\b";
        keywordPatternsC89 << "\\bsizeof\\b";
        keywordPatternsC89 << "\\bstatic\\b";
        keywordPatternsC89 << "\\bstruct\\b";
        keywordPatternsC89 << "\\bswitch\\b";
        keywordPatternsC89 << "\\btypedef\\b";
        keywordPatternsC89 << "\\bunion\\b";
        keywordPatternsC89 << "\\bunsigned\\b";
        keywordPatternsC89 << "\\bvoid\\b";
        keywordPatternsC89 << "\\bvolatile\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\band\\b";
        keywordPatternsC89 << "\\band_eq\\b";
        keywordPatternsC89 << "\\basm\\b";
        keywordPatternsC89 << "\\bbitand\\b";
        keywordPatternsC89 << "\\bbitor\\b";
        keywordPatternsC89 << "\\bbool\\b";
        keywordPatternsC89 << "\\bcatch\\b";
        keywordPatternsC89 << "\\bclass\\b";
        keywordPatternsC89 << "\\bcompl\\b";
        keywordPatternsC89 << "\\bconst_cast\\b";
        keywordPatternsC89 << "\\bdelete\\b";
        keywordPatternsC89 << "\\bdynamic_cast\\b";
        keywordPatternsC89 << "\\bexplicit\\b";
        keywordPatternsC89 << "\\bexport\\b";
        keywordPatternsC89 << "\\bfalse\\b";
        keywordPatternsC89 << "\\bfriend\\b";
        keywordPatternsC89 << "\\binline\\b";
        keywordPatternsC89 << "\\bwhile\\b";
        keywordPatternsC89 << "\\bmutable\\b";
        keywordPatternsC89 << "\\bnamespace\\b";
        keywordPatternsC89 << "\\bnew\\b";
        keywordPatternsC89 << "\\bnot\\b";
        keywordPatternsC89 << "\\bnot_eq\\b";
        keywordPatternsC89 << "\\boperator\\b";
        keywordPatternsC89 << "\\bor\\b";
        keywordPatternsC89 << "\\bor_eq\\b";
        keywordPatternsC89 << "\\bprivate\\b";
        keywordPatternsC89 << "\\bprotected\\b";
        keywordPatternsC89 << "\\bpublic\\b";
        keywordPatternsC89 << "\\breinterpret_cast\\b";
        keywordPatternsC89 << "\\bstatic_cast\\b";
        keywordPatternsC89 << "\\btemplate\\b";
        keywordPatternsC89 << "\\bthis\\b";
        keywordPatternsC89 << "\\bthrow\\b";
        keywordPatternsC89 << "\\btrue\\b";
        keywordPatternsC89 << "\\btry\\b";
        keywordPatternsC89 << "\\btypeid\\b";
        keywordPatternsC89 << "\\btypename\\b";
        keywordPatternsC89 << "\\busing\\b";
        keywordPatternsC89 << "\\bvirtual\\b";
        keywordPatternsC89 << "\\bwchar_t\\b";
        keywordPatternsC89 << "\\bxor\\b";
        keywordPatternsC89 << "\\bxor_eq\\b";

         keywordPatternsC89 << "\\balignas\\b";
          keywordPatternsC89 << "\\balignof\\b";
           keywordPatternsC89 << "\\bchar16_t\\b";
            keywordPatternsC89 << "\\bchar32_t\\b";
             keywordPatternsC89 << "\\bconstexpr\\b";
              keywordPatternsC89 << "\\bdecltype\\b";
               keywordPatternsC89 << "\\bnoexcept\\b";
                keywordPatternsC89 << "\\bnullptr\\b";
                 keywordPatternsC89 << "\\bstatic_assert\\b";
                  keywordPatternsC89 << "\\bthread_local\\b";

                  keywordPatternsC89 << "\\bchar8_t\\b";
                  keywordPatternsC89 << "\\bconcept\\b";
                  keywordPatternsC89 << "\\bconsteval\\b";
                  keywordPatternsC89 << "\\bconstinit\\b";
                  keywordPatternsC89 << "\\bco_await\\b";
                  keywordPatternsC89 << "\\bco_return\\b";
                  keywordPatternsC89 << "\\bco_yield\\b";
                  keywordPatternsC89 << "\\brequires\\b";


        break;
    }
//    keywordPatterns = keywordPatternsC89;

    for (const QString &pattern : keywordPatternsC89) {
        rule.pattern = QRegExp(pattern);
        rule.format = keywordFormat;
        highlightingRules.append(rule);
    }
    classFormat.setFontWeight(QFont::Bold);
        classFormat.setForeground(Qt::darkMagenta);
        rule.pattern = QRegExp("\\bQ[A-Za-z]+\\b");
        rule.format = classFormat;
        highlightingRules.append(rule);

        quotationFormat.setForeground(Qt::darkGreen);
        rule.pattern = QRegExp("\".*\"");
        rule.format = quotationFormat;
        highlightingRules.append(rule);

        functionFormat.setFontItalic(true);
        functionFormat.setForeground(Qt::blue);
        rule.pattern = QRegExp("\\b[A-Za-z0-9_]+(?=\\()");
        rule.format = functionFormat;
        highlightingRules.append(rule);
        singleLineCommentFormat.setForeground(Qt::red);
            rule.pattern = QRegExp("//[^\n]*");
            rule.format = singleLineCommentFormat;
            highlightingRules.append(rule);

            multiLineCommentFormat.setForeground(Qt::red);

            commentStartExpression = QRegExp("/\\*");
            multiLineCommentFormat.setForeground(Qt::red);
            commentEndExpression = QRegExp("\\*/");
}

void Highlighter::SetPresetButton(QVector<QColor> ab, std::string b)
{
    highlightingRules.clear();

    SwitchStandart(b);

    if (ab.at(0) !=nullptr){
        //комменты
          HighlightingRule rule;
        singleLineCommentFormat.setForeground(ab.at(0));
        rule.pattern = QRegExp("//[^\n]*");
        rule.format = singleLineCommentFormat;
        highlightingRules.append(rule);
        multiLineCommentFormat.setForeground(ab.at(0));

                commentStartExpression = QRegExp("/\\*");
                multiLineCommentFormat.setForeground(ab.at(0));
                commentEndExpression = QRegExp("\\*/");

    }

    if (ab.at(1) !=nullptr){
        //ключевые слова
          HighlightingRule rule;
        keywordFormat.setForeground(ab.at(1));
        keywordFormat.setFontWeight(QFont::Bold);



        for (const QString &pattern : keywordPatternsC89) {
            rule.pattern = QRegExp(pattern);
            rule.format = keywordFormat;
            highlightingRules.append(rule);
        }


    }

    if (ab.at(2) !=nullptr){
        //литералы
          HighlightingRule rule;
                quotationFormat.setForeground(ab.at(2));
                rule.pattern = QRegExp("\".*\"");
                rule.format = quotationFormat;
                highlightingRules.append(rule);
    }


}
