#include "spravka.h"
#include "ui_spravka.h"
#include <QtGlobal>

Spravka::Spravka(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Spravka)

{
    ui->setupUi(this);

    ui->label_2->setText(trUtf8("Дата сборки: ") + QString(__DATE__)+ QString(" ") + QString(__TIME__) + trUtf8("\nверсия Qt: ") + qVersion());
    QPixmap pix(":/new/prefix1/Rodik!/bBeElUNINpc.jpg");
    int w = ui->label->width();
    int h = ui->label->height();
    ui->label->setPixmap(pix.scaled(w,h, Qt::KeepAspectRatio));
}

Spravka::~Spravka()
{
    delete ui;
}

void Spravka::on_pushButton_clicked()
{
    close();
}
