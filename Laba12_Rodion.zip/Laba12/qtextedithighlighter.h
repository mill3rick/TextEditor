#ifndef QTEXTEDITHIGHLIGHTER_H
#define QTEXTEDITHIGHLIGHTER_H
#pragma once
#include <QPlainTextEdit>
class QTextEditHighlighter : public QPlainTextEdit
{
    Q_OBJECT

public:
    QWidget *lineNumberArea;
    explicit QTextEditHighlighter(QWidget *parent = 0);
    void SetColor(QColor a);
    int getFirstVisibleBlockId();
    void lineNumberAreaPaintEvent(QPaintEvent *event);
    int lineNumberAreaWidth();

signals:


public slots:

    void resizeEvent(QResizeEvent *e);

private slots:

    void updateLineNumberAreaWidth(int newBlockCount);
    void updateLineNumberArea(QRectF);
    void updateLineNumberArea(int);
    void updateLineNumberArea();
    void highlightCurrentLine();

private:
    QColor lineColor = QColor(Qt::yellow);


};

#endif // QTEXTEDITHIGHLIGHTER_H
