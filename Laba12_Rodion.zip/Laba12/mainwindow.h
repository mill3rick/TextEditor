#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#pragma once
#include <QMainWindow>
#include <QTextEdit>
#include "highlighter.h"
#include <QDateTime>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private:
    Highlighter* highlighter;
    QVector<QColor> mda = {nullptr, nullptr, nullptr};
    std::string next;
    QVector<QVector<QColor>> ne_beite;
    bool gg = 1;
    QMap<QAction*, int> MyMap;
    QTextEdit* pervii;
    QTextEdit* vtoroi;
    int kostyl = -1;
    QDateTime last_read;
    QDateTime last_mod;
    QString OpenedDir;
    QString bufname;
    QString buffer;

private slots:
    void on_action_2_triggered();

    void on_action_4_triggered();

    void on_action_3_triggered();

    void on_action_27_triggered();

    void on_action_28_triggered();

    void on_action_triggered();

    void on_action_22_triggered();

    void on_action_6_triggered();

    void on_action_29_triggered();

    void on_action_30_triggered();

    void on_action_7_triggered();

    void on_action_31_triggered();

    void on_action_8_triggered();

    void on_action_9_triggered();

    void on_action_32_triggered();

    void on_action_10_triggered();

    void on_action_33_triggered();

    void on_action_13_triggered();

    void on_action_16_triggered();

    void on_action_15_triggered();

    void on_action_14_triggered(bool checked);

    void on_action_26_triggered();

    void on_action_5_triggered();

    void on_action_11_triggered();

    void on_Find_text_triggered();

    void on_showCursorPos_triggered();

    void on_action_19_triggered(bool checked);

    void on_action_20_triggered(bool checked);

    void on_action_17_triggered();

    void on_action_12_triggered();

    void on_Replace_text_triggered();

    void on_GoToFind_triggered();

    void on_action_25_triggered();

    void on_action_98_triggered();

    void on_action_03_triggered();

    void on_action_34_triggered();

    void on_action_35_triggered();

    void on_action_36_triggered();

    void on_action_37_triggered();

    void on_action_40_triggered(bool checked);

    void on_action_41_triggered();

    void on_actionfisting_triggered();

    void on_actionisthree_triggered();

    void on_actionhundredbucks_triggered();
    
    void on_actionsolyanovo_triggered();

    void on_action_42_triggered();

    void on_action_18_triggered(bool checked);

    void on_actionDefault_2_triggered();

    void on_actionsetstylefrombutton_triggered();

private:
    Ui::MainWindow *ui;




};
#endif // MAINWINDOW_H
